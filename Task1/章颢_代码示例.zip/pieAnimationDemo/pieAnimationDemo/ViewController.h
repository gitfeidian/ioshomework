//
//  ViewController.h
//  pieAnimationDemo
//
//  Created by ziggear on 13-4-27.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    //控件成员
    UIImageView *mainImage;   //图片控件
    UIButton *startButton;    //开始按钮
    UIButton *stopButton;     //停止按钮
    UISlider *speedSlider;    //速度滑块
    
    //参数成员
    NSMutableArray *imageObjects;    //图片对象数组
}

@property (nonatomic, retain) UIImageView *mainImage;
@property (nonatomic, retain) UIButton *startButton;
@property (nonatomic, retain) UIButton *stopButton;
@property (nonatomic, retain) UISlider *speedSlider;
@property (nonatomic, retain) NSMutableArray *imageObjects;
@end
