//
//  ViewController.m
//  pieAnimationDemo
//
//  Created by ziggear on 13-4-27.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize mainImage, startButton, stopButton, speedSlider;
@synthesize imageObjects;

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if(self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]){
        
        //设置视图参数...
        
        [self.view setBackgroundColor:[UIColor grayColor]];
        
        //初始化控件并加到视图上
        
        mainImage = [[UIImageView alloc] initWithFrame:CGRectMake(10, 20, 300, 300)];
        [mainImage setBackgroundColor:[UIColor whiteColor]];
        [mainImage setAnimationDuration:2.5];
        [mainImage setAnimationRepeatCount:-1];
        [self.view addSubview:mainImage];
        
        startButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [startButton setFrame:CGRectMake(10, 340, 100, 50)];
        [startButton setTitle:@"Start" forState:UIControlStateNormal];
        [self.view addSubview:startButton];
        
        stopButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [stopButton setFrame:CGRectMake(210, 340, 100, 50)];
        [stopButton setTitle:@"Stop" forState:UIControlStateNormal];
        [self.view addSubview:stopButton];
        
        speedSlider = [[UISlider alloc] initWithFrame:CGRectMake(10, 410, 300, 20)];
        [speedSlider setMaximumValue:5.0f];
        [speedSlider setMinimumValue:0.1f];
        [speedSlider setValue:2.5f];
        [self.view addSubview:speedSlider];
        
        //初始化图片数组
        //initWithCapacity 方法是按容量初始化  实际使用的时候即使超出这个容量也没问题。
        imageObjects = [[NSMutableArray alloc] initWithCapacity:9];
        
        //关联控件和本地事件：
        
        [startButton addTarget:self action:@selector(startAnimation) forControlEvents:UIControlEventTouchUpInside];
        
        [stopButton addTarget:self action:@selector(stopAnmation) forControlEvents:UIControlEventTouchUpInside];
        
        [speedSlider addTarget:self action:@selector(speedChanged) forControlEvents:UIControlEventValueChanged];
        
        // startButton/stopButton 的事件 UIControlEventTouchUpInside 被分别关联
        // 到startAnimation/stopAnimation 这两个函数里，所以当这两个控件被按下时会触发这两个函数
        // speedSlider 的事件 UIControlEventValueChanged 被关联到 speedChanged
        // 所以当 speedSlider的值改变的时候，speedChanged函数被触发
        
        
        //执行本地函数
        [self setImage];
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
}



#pragma mark - Animation Control

- (void) setImage {
    //循环添加图片到 imageObjects 数组
    for(int i=1; i <= 9; i++){
        NSString *nameString = [NSString stringWithFormat:@"%d.jpg",i];
        UIImage *tempImage = [UIImage imageNamed:nameString];
        [imageObjects addObject:tempImage];
    }
    
    //把图片数组赋给 mainImage 对象
    [mainImage setAnimationImages:imageObjects];
    
}

- (void) startAnimation {
    [mainImage startAnimating];
}

- (void) stopAnmation {
    [mainImage stopAnimating];
}

- (void) speedChanged {
    [self stopAnmation];
    
    //从 speedSlider 控件中获取到value
    float speed = speedSlider.value;
    [mainImage setAnimationDuration:speed];
    
    [self startAnimation];
}

@end
