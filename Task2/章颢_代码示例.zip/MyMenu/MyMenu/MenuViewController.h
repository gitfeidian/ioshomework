//
//  MenuViewController.h
//  MyMenu
//
//  Created by ziggear on 13-5-28.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSArray *dataSource;
@property (nonatomic, strong) UITableView *mainTable;
@end
