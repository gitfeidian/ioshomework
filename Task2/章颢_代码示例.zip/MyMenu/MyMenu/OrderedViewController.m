//
//  OrderedViewController.m
//  MyMenu
//
//  Created by ziggear on 13-5-28.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import "OrderedViewController.h"

@interface OrderedViewController ()

@end

@implementation OrderedViewController
@synthesize dataSource, mainTable;

- (id) initWithArray:(NSArray *)arr
{
    self = [super init];
    if (self) {
        // Custom initialization
        self.title = @"已点";
        
        self.dataSource = arr;
        
        mainTable = [[UITableView alloc] initWithFrame:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height)];
        mainTable.dataSource = self;
        mainTable.delegate = self;
        [self.view addSubview:mainTable];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataSource count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    cell = [tableView dequeueReusableCellWithIdentifier:@"menuCell"];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"menuCell"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleBlue];
    }
    
    [cell.textLabel setText:[dataSource objectAtIndex:[indexPath row]]];
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSelector:@selector(unselectCell:) withObject:indexPath afterDelay:0.2];
}

#pragma mark - Selection
- (void)unselectCell:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self.mainTable cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO];
}
@end
