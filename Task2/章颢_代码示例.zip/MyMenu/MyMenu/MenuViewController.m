//
//  MenuViewController.m
//  MyMenu
//
//  Created by ziggear on 13-5-28.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import "MenuViewController.h"
#import "OrderedViewController.h"

@interface MenuViewController () {
    NSMutableArray *selected;
}

@end

@implementation MenuViewController
@synthesize dataSource, mainTable;
- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        self.title = @"菜单";
        
        self.dataSource = [NSArray arrayWithObjects:@"番茄鸡蛋",@"鱼香肉丝",@"宫保鸡丁", nil];
        
        mainTable = [[UITableView alloc] initWithFrame:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height)];
        mainTable.dataSource = self;
        mainTable.delegate = self;
        [self.view addSubview:mainTable];
        
        selected = [[NSMutableArray alloc] init];
        
        UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStylePlain target:self action:@selector(selectionDone)];
        self.navigationItem.rightBarButtonItem = rightBtn;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataSource count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    cell = [tableView dequeueReusableCellWithIdentifier:@"menuCell"];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"menuCell"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleBlue];
    }
    
    [cell.textLabel setText:[dataSource objectAtIndex:[indexPath row]]];
    return cell;
}
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *nowCell = [tableView cellForRowAtIndexPath: indexPath];
    NSString *nowText = [nowCell textLabel].text;
    @try{
        if (nowCell.accessoryType == UITableViewCellAccessoryNone) {
            nowCell.accessoryType = UITableViewCellAccessoryCheckmark;
            
            [selected addObject:[self.dataSource objectAtIndex:[indexPath row]]];
            
        } else {
            nowCell.accessoryType = UITableViewCellAccessoryNone;
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            
            
            for(NSString *name in selected){
                if ([name isEqualToString:nowText]){
                    [selected removeObject:name];
                }
            }
        }
    }
    
    @catch (NSException *exp) {
        
    }
    [self performSelector:@selector(unselectCell:) withObject:indexPath afterDelay:0.2];
}

#pragma mark - Selection

- (void) selectionDone {
    OrderedViewController *vc = [[OrderedViewController alloc] initWithArray:selected];
    [self.navigationController pushViewController:vc animated:YES];
}


- (void)unselectCell:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self.mainTable cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO];
}
@end
